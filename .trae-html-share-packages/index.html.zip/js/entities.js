/* ============ 游戏实体：潜艇 / 水雷 / 深水炸弹 / 驱逐舰 ============ */

/* ---------------- 潜艇 ---------------- */
class Submarine {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.tx = x;
    this.ty = y;
    this.vx = 0;
    this.vy = 0;
    this.facing = 1;
    this.pitch = 0;
    this.invuln = 0;
    this.alive = true;
    this.hitFlash = 0;
    this.propTimer = 0;
  }

  update(dt) {
    const P = CFG.PLAYER;

    this.tx = Utils.clamp(Input.mx, P.MIN_X, P.MAX_X);
    this.ty = Utils.clamp(Input.my, P.MIN_Y, P.MAX_Y);

    const nx = Utils.damp(this.x, this.tx, P.FOLLOW, dt);
    const ny = Utils.damp(this.y, this.ty, P.FOLLOW, dt);

    if (dt > 0.0001) {
      this.vx = (nx - this.x) / dt;
      this.vy = (ny - this.y) / dt;
    }
    this.x = nx;
    this.y = ny;

    if (Math.abs(this.vx) > 12) this.facing = this.vx > 0 ? 1 : -1;
    this.pitch = Utils.clamp(this.vy * 0.0014, -0.22, 0.22);

    if (this.invuln > 0) this.invuln = Math.max(0, this.invuln - dt);
    if (this.hitFlash > 0) this.hitFlash = Math.max(0, this.hitFlash - dt);

    // 螺旋桨气泡
    this.propTimer -= dt;
    if (this.propTimer <= 0) {
      this.propTimer = 0.085;
      FX.bubble(this.x - this.facing * 60, this.y + 2, 1, { spread: 3, speed: 18, size: 1 });
    }
  }

  idle(dt) {
    this.y = CFG.PLAYER.START_Y + Math.sin(World.time * 1.1) * 8;
    this.pitch = Math.sin(World.time * 1.1 + 0.6) * 0.02;
    if (this.invuln > 0) this.invuln = Math.max(0, this.invuln - dt);
  }

  draw(ctx, time) {
    if (!this.alive) return;

    const blink = this.invuln > 0 ? 0.4 + 0.6 * Math.abs(Math.sin(time * 22)) : 1;

    ctx.save();
    ctx.globalAlpha = blink;
    ctx.translate(this.x, this.y);
    ctx.rotate(this.pitch * this.facing);
    ctx.scale(this.facing, 1);

    // 头部探照灯
    const lg = ctx.createLinearGradient(52, 0, 240, 0);
    lg.addColorStop(0, 'rgba(140,245,255,0.12)');
    lg.addColorStop(1, 'rgba(140,245,255,0)');
    ctx.fillStyle = lg;
    ctx.beginPath();
    ctx.moveTo(50, -7);
    ctx.lineTo(240, -48);
    ctx.lineTo(240, 48);
    ctx.lineTo(50, 7);
    ctx.closePath();
    ctx.fill();

    // 尾鳍
    ctx.fillStyle = CFG.COLORS.hullDark;
    ctx.strokeStyle = 'rgba(95,242,255,0.35)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(-40, -10);
    ctx.lineTo(-66, -17);
    ctx.lineTo(-58, 0);
    ctx.lineTo(-66, 17);
    ctx.lineTo(-40, 10);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();

    // 螺旋桨
    ctx.save();
    ctx.translate(-68, 0);
    ctx.rotate(time * 15);
    ctx.strokeStyle = 'rgba(160,248,255,0.55)';
    ctx.lineWidth = 1.5;
    for (let i = 0; i < 3; i++) {
      ctx.rotate((Math.PI * 2) / 3);
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.lineTo(0, -11);
      ctx.stroke();
    }
    ctx.restore();

    // 艇体光晕
    ctx.shadowColor = 'rgba(95,242,255,0.5)';
    ctx.shadowBlur = 14;

    const hull = ctx.createLinearGradient(0, -18, 0, 18);
    hull.addColorStop(0, '#1a4c63');
    hull.addColorStop(0.45, CFG.COLORS.hullMid);
    hull.addColorStop(1, CFG.COLORS.hullDark);

    ctx.fillStyle = hull;
    ctx.beginPath();
    ctx.ellipse(0, 0, 58, 16, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.shadowBlur = 0;

    ctx.strokeStyle = 'rgba(95,242,255,0.85)';
    ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.ellipse(0, 0, 58, 16, 0, 0, Math.PI * 2);
    ctx.stroke();

    // 顶部高光
    ctx.strokeStyle = 'rgba(210,252,255,0.5)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.ellipse(0, -1, 52, 12, 0, Math.PI * 1.12, Math.PI * 1.88);
    ctx.stroke();

    // 艇体分缝
    ctx.strokeStyle = 'rgba(0,0,0,0.35)';
    ctx.beginPath();
    ctx.moveTo(-18, -14);
    ctx.lineTo(-18, 14);
    ctx.moveTo(8, -15);
    ctx.lineTo(8, 15);
    ctx.stroke();

    // 指挥塔
    const sail = ctx.createLinearGradient(0, -30, 0, -12);
    sail.addColorStop(0, '#1d536a');
    sail.addColorStop(1, '#0a2534');
    ctx.fillStyle = sail;
    ctx.strokeStyle = 'rgba(95,242,255,0.7)';
    ctx.lineWidth = 1;
    Utils.roundRect(ctx, -14, -31, 34, 18, 7);
    ctx.fill();
    ctx.stroke();

    // 潜望镜
    ctx.strokeStyle = 'rgba(160,248,255,0.65)';
    ctx.lineWidth = 1.4;
    ctx.beginPath();
    ctx.moveTo(4, -31);
    ctx.lineTo(4, -45);
    ctx.lineTo(-2, -45);
    ctx.stroke();

    // 布雷舱口
    ctx.fillStyle = 'rgba(255,200,87,0.85)';
    ctx.beginPath();
    ctx.arc(13, -22, 2.2, 0, Math.PI * 2);
    ctx.fill();

    // 舷窗
    for (const px of [14, 27, 40]) {
      ctx.fillStyle = 'rgba(120,242,255,0.95)';
      ctx.beginPath();
      ctx.arc(px, 1, 2, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = 'rgba(255,255,255,0.75)';
      ctx.beginPath();
      ctx.arc(px, 0.4, 0.9, 0, Math.PI * 2);
      ctx.fill();
    }

    // 受击红闪
    if (this.hitFlash > 0) {
      ctx.fillStyle = Utils.rgba(CFG.COLORS.dangerRGB, this.hitFlash * 0.7);
      ctx.beginPath();
      ctx.ellipse(0, 0, 58, 16, 0, 0, Math.PI * 2);
      ctx.fill();
    }

    ctx.restore();

    // 无敌护盾环
    if (this.invuln > 0) {
      ctx.save();
      ctx.translate(this.x, this.y);
      ctx.rotate(time * 1.8);
      ctx.setLineDash([7, 8]);
      ctx.strokeStyle = 'rgba(95,242,255,0.5)';
      ctx.lineWidth = 1.4;
      ctx.beginPath();
      ctx.arc(0, 0, 38, 0, Math.PI * 2);
      ctx.stroke();
      ctx.setLineDash([]);
      ctx.restore();
    }
  }
}

/* ---------------- 水雷 ---------------- */
class Mine {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.state = 'rising';        // rising → armed → sinking
    this.fuse = CFG.MINE.ARM_TIME;
    this.bob = Utils.rand(0, Math.PI * 2);
    this.t = 0;
    this.sinkT = 0;
    this.alpha = 1;
    this.dead = false;
    this.trailTimer = 0;
  }

  isArmed() {
    return this.state === 'armed';
  }

  update(dt) {
    const M = CFG.MINE;
    this.t += dt;

    if (this.state === 'rising') {
      this.y -= M.RISE_SPEED * dt;
      this.x += Math.sin(this.t * 8) * 12 * dt;

      this.trailTimer -= dt;
      if (this.trailTimer <= 0) {
        this.trailTimer = 0.07;
        FX.bubble(this.x, this.y + 12, 1, { spread: 3, speed: 20, size: 1.1 });
      }

      if (this.y <= CFG.SURFACE_Y) {
        this.y = CFG.SURFACE_Y;
        this.state = 'armed';
        this.fuse = M.ARM_TIME;
        AudioSys.play('mine_armed');
        FX.ring(this.x, CFG.SURFACE_Y, {
          maxR: 24, life: 0.35, width: 1.4, rgb: CFG.COLORS.cyanRGB
        });
      }
    } else if (this.state === 'armed') {
      this.fuse -= dt;
      if (this.fuse <= 0) {
        this.state = 'sinking';
        this.sinkT = 0;
        AudioSys.play('mine_expire');
        FX.bubble(this.x, this.y, 4, { spread: 5, speed: 18, size: 1.2 });
      }
    } else if (this.state === 'sinking') {
      this.sinkT += dt;
      this.y += 34 * dt;
      this.alpha = Math.max(0, 1 - this.sinkT / M.SINK_TIME);
      if (this.sinkT >= M.SINK_TIME) this.dead = true;
    }
  }

  draw(ctx, time) {
    const M = CFG.MINE;
    const y = this.state === 'armed'
      ? this.y + Math.sin(time * M.BOB_SPEED + this.bob) * M.BOB_AMP
      : this.y;

    ctx.save();
    ctx.globalAlpha = this.alpha;

    // 光晕
    const glow = ctx.createRadialGradient(this.x, y, 2, this.x, y, 28);
    glow.addColorStop(0, 'rgba(255,200,87,0.38)');
    glow.addColorStop(0.5, 'rgba(255,200,87,0.1)');
    glow.addColorStop(1, 'rgba(255,200,87,0)');
    ctx.fillStyle = glow;
    ctx.beginPath();
    ctx.arc(this.x, y, 28, 0, Math.PI * 2);
    ctx.fill();

    // 引信环
    if (this.state === 'armed') {
      const ratio = Utils.clamp(this.fuse / M.ARM_TIME, 0, 1);
      const hot = this.fuse < 0.65;
      ctx.strokeStyle = 'rgba(95,242,255,0.16)';
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.arc(this.x, y, 21, 0, Math.PI * 2);
      ctx.stroke();

      ctx.strokeStyle = hot ? CFG.COLORS.danger : CFG.COLORS.amber;
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.arc(this.x, y, 21, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * ratio);
      ctx.stroke();
    }

    // 尖刺
    ctx.strokeStyle = 'rgba(180,235,245,0.8)';
    ctx.lineWidth = 1.6;
    for (let i = 0; i < 8; i++) {
      const a = (Math.PI * 2 * i) / 8 + this.bob;
      ctx.beginPath();
      ctx.moveTo(this.x + Math.cos(a) * 9, y + Math.sin(a) * 9);
      ctx.lineTo(this.x + Math.cos(a) * 16, y + Math.sin(a) * 16);
      ctx.stroke();
    }

    // 雷体
    const body = ctx.createRadialGradient(this.x - 3, y - 3, 1, this.x, y, 10);
    body.addColorStop(0, '#3d5b68');
    body.addColorStop(0.6, '#1b303a');
    body.addColorStop(1, '#080f14');
    ctx.fillStyle = body;
    ctx.beginPath();
    ctx.arc(this.x, y, 9.5, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = 'rgba(95,242,255,0.55)';
    ctx.lineWidth = 1;
    ctx.stroke();

    // 信号灯
    const blink = 0.45 + 0.55 * Math.abs(Math.sin(time * 9 + this.bob));
    ctx.fillStyle = this.state === 'sinking'
      ? 'rgba(120,140,150,0.4)'
      : `rgba(255,200,87,${blink})`;
    ctx.beginPath();
    ctx.arc(this.x, y, 2.6, 0, Math.PI * 2);
    ctx.fill();

    ctx.restore();
  }
}

/* ---------------- 深水炸弹 ---------------- */
class DepthCharge {
  constructor(x, depth, game) {
    this.baseX = x;
    this.x = x;
    this.y = CFG.SURFACE_Y;
    this.depth = depth;
    this.t = Utils.rand(0, Math.PI * 2);
    this.warn = -1;
    this.dead = false;
    this.canceled = false;
    this.cancelT = 0;
    this.alpha = 1;
    this.game = game;
    this.bubbleTimer = 0;
  }

  cancel() {
    if (this.canceled) return;
    this.canceled = true;
    this.cancelT = 0;
  }

  update(dt) {
    this.t += dt;

    if (this.canceled) {
      this.cancelT += dt;
      this.alpha = Math.max(0, 1 - this.cancelT / 0.4);
      if (this.cancelT >= 0.4) this.dead = true;
      return;
    }

    this.y += CFG.CHARGE.SINK_SPEED * dt;
    this.x = this.baseX + Math.sin(this.t * 2.2) * 7;

    const remain = (this.depth - this.y) / CFG.CHARGE.SINK_SPEED;
    this.warn = remain <= CFG.CHARGE.WARNING ? Math.max(remain, 0) : -1;

    this.bubbleTimer -= dt;
    if (this.bubbleTimer <= 0) {
      this.bubbleTimer = 0.09;
      FX.bubble(this.x, this.y - 6, 1, { spread: 3, speed: 22, size: 1.1 });
    }

    if (this.y >= this.depth) {
      this.dead = true;
      this.game.onChargeExplode(this);
    }
  }

  draw(ctx, time) {
    const C = CFG.CHARGE;

    if (!this.canceled) {
      // 预测爆炸圈
      const warnHot = this.warn >= 0;
      const a = warnHot
        ? 0.26 + 0.38 * Math.abs(Math.sin(time * 18))
        : 0.1;
      ctx.save();
      ctx.setLineDash([6, 8]);
      ctx.strokeStyle = Utils.rgba(CFG.COLORS.dangerRGB, a);
      ctx.lineWidth = warnHot ? 2 : 1.2;
      ctx.beginPath();
      ctx.arc(this.x, this.depth, C.BLAST_RADIUS, 0, Math.PI * 2);
      ctx.stroke();
      ctx.setLineDash([]);

      // 下沉导轨
      ctx.strokeStyle = 'rgba(255,77,109,0.1)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(this.x, CFG.SURFACE_Y);
      ctx.lineTo(this.x, this.depth);
      ctx.stroke();
      ctx.restore();
    }

    ctx.save();
    ctx.globalAlpha = this.alpha;
    ctx.translate(this.x, this.y);

    // 桶体
    ctx.fillStyle = '#18232a';
    ctx.strokeStyle = 'rgba(255,77,109,0.7)';
    ctx.lineWidth = 1;
    Utils.roundRect(ctx, -5, -11, 10, 22, 3);
    ctx.fill();
    ctx.stroke();

    // 尾翼
    ctx.fillStyle = '#0d151a';
    ctx.fillRect(-8, -14, 16, 3);
    ctx.fillRect(-8, 8, 16, 3);

    // 红色信号灯
    const blink = 0.35 + 0.65 * Math.abs(Math.sin(time * (this.warn >= 0 ? 22 : 7)));
    ctx.fillStyle = Utils.rgba(CFG.COLORS.dangerRGB, blink);
    ctx.beginPath();
    ctx.arc(0, 0, 2, 0, Math.PI * 2);
    ctx.fill();

    ctx.restore();
  }
}

/* ---------------- 驱逐舰 ---------------- */
class Destroyer {
  constructor(entry, level) {
    const cls = CFG.SHIPS[entry.type];

    this.type = entry.type;
    this.cls = cls;
    this.len = cls.len;
    this.beam = cls.beam;
    this.maxHp = cls.hp;
    this.hp = cls.hp;
    this.speed = cls.speed * level.speedMul * (entry.fast ? cls.fast : 1);
    this.interval = cls.drop * level.intervalMul;
    this.quota = cls.quota;

    this.x = -this.len / 2 - Utils.rand(0, 30);
    this.y = CFG.SURFACE_Y;
    this.phase = Utils.rand(0, Math.PI * 2);
    this.dropTimer = Utils.rand(0.8, 1.6);
    this.hitFlash = 0;
    this.sinking = false;
    this.sinkT = 0;
    this.dead = false;
    this.escaped = false;
    this.wakeTimer = 0;
    this.smokeTimer = 0;
  }

  update(dt, game) {
    this.phase += dt;

    if (this.sinking) {
      this.sinkT += dt;
      this.x += 8 * dt;
      this.y = CFG.SURFACE_Y + this.sinkT * 44;

      this.smokeTimer -= dt;
      if (this.smokeTimer <= 0) {
        this.smokeTimer = 0.12;
        FX.smoke(this.x + Utils.rand(-this.len * 0.3, this.len * 0.2), this.y - this.beam * 0.4, 1);
        FX.bubble(this.x + Utils.rand(-this.len * 0.3, this.len * 0.3), this.y, 2, {
          spread: 8, speed: 26, size: 1.6
        });
        FX.foam(this.x, CFG.SURFACE_Y + 4, 2, { spread: this.len * 0.35 });
      }

      if (this.sinkT >= 1.6) this.dead = true;
      return;
    }

    this.x += this.speed * dt;
    this.y = CFG.SURFACE_Y + Math.sin(this.phase * 1.3) * 1.4;
    if (this.hitFlash > 0) this.hitFlash = Math.max(0, this.hitFlash - dt);

    // 投放深水炸弹
    if (this.quota > 0 && this.x > CFG.CHARGE.DROP_MIN_X && this.x < CFG.CHARGE.DROP_MAX_X) {
      this.dropTimer -= dt;
      if (this.dropTimer <= 0) {
        this.quota--;
        this.dropTimer = this.interval * Utils.rand(0.85, 1.15);
        game.dropDepthCharge(this.x);
      }
    }

    // 尾流泡沫
    this.wakeTimer -= dt;
    if (this.wakeTimer <= 0) {
      this.wakeTimer = 0.09;
      FX.foam(this.x - this.len * 0.42, CFG.SURFACE_Y + this.beam * 0.35, 1, { spread: 4 });
    }

    // 受损冒烟
    if (this.hp < this.maxHp) {
      this.smokeTimer -= dt;
      if (this.smokeTimer <= 0) {
        this.smokeTimer = 0.22;
        FX.smoke(this.x + Utils.rand(-this.len * 0.2, this.len * 0.2), this.y - this.beam, 1);
      }
    }

    if (this.x > CFG.W + this.len / 2) this.escaped = true;
  }

  /* 返回 true 表示这一击造成击沉 */
  hit(dmg) {
    if (this.sinking) return false;
    this.hp -= dmg;
    this.hitFlash = 0.38;
    if (this.hp <= 0) {
      this.hp = 0;
      this.sinking = true;
      this.sinkT = 0;
      this.quota = 0;
      return true;
    }
    return false;
  }

  draw(ctx, time) {
    const hl = this.len / 2;
    const bh = this.beam / 2;
    const sinkRatio = this.sinking ? Utils.clamp(this.sinkT / 1.6, 0, 1) : 0;

    ctx.save();
    ctx.globalAlpha = this.sinking ? 1 - sinkRatio * 0.55 : 1;
    ctx.translate(this.x, this.y);
    if (this.sinking) ctx.rotate(sinkRatio * 0.24);

    // 探照灯
    if (!this.sinking) {
      const cone = ctx.createLinearGradient(0, -bh, 0, 330);
      cone.addColorStop(0, 'rgba(140,245,255,0.09)');
      cone.addColorStop(1, 'rgba(140,245,255,0)');
      ctx.fillStyle = cone;
      ctx.beginPath();
      ctx.moveTo(-this.len * 0.04, -bh - 10);
      ctx.lineTo(this.len * 0.1, -bh - 10);
      ctx.lineTo(this.len * 0.48, 330);
      ctx.lineTo(-this.len * 0.34, 330);
      ctx.closePath();
      ctx.fill();
    }

    // 船体
    const hull = ctx.createLinearGradient(0, -bh, 0, bh);
    hull.addColorStop(0, '#22323b');
    hull.addColorStop(0.45, CFG.COLORS.shipMid);
    hull.addColorStop(1, CFG.COLORS.shipDark);

    ctx.beginPath();
    ctx.moveTo(-hl, -bh * 0.45);
    ctx.lineTo(-hl * 0.72, -bh);
    ctx.lineTo(hl * 0.55, -bh);
    ctx.lineTo(hl * 0.9, -bh * 0.3);
    ctx.lineTo(hl, bh * 0.18);
    ctx.lineTo(hl * 0.62, bh * 0.85);
    ctx.lineTo(-hl * 0.86, bh * 0.85);
    ctx.lineTo(-hl, bh * 0.32);
    ctx.closePath();
    ctx.fillStyle = hull;
    ctx.fill();
    ctx.strokeStyle = 'rgba(95,242,255,0.62)';
    ctx.lineWidth = 1.1;
    ctx.stroke();

    // 甲板线
    ctx.strokeStyle = 'rgba(95,242,255,0.35)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(-hl * 0.9, -bh * 0.45);
    ctx.lineTo(hl * 0.72, -bh * 0.45);
    ctx.stroke();

    // 水线
    ctx.strokeStyle = 'rgba(95,242,255,0.22)';
    ctx.beginPath();
    ctx.moveTo(-hl * 0.86, bh * 0.4);
    ctx.lineTo(hl * 0.62, bh * 0.4);
    ctx.stroke();

    // 舰桥
    const bw = this.len * 0.16;
    const bx = -this.len * 0.04;
    ctx.fillStyle = '#1b2c36';
    ctx.strokeStyle = 'rgba(95,242,255,0.55)';
    Utils.roundRect(ctx, bx, -bh - 17, bw, 18, 2);
    ctx.fill();
    ctx.stroke();

    // 舰桥舷窗
    ctx.fillStyle = 'rgba(120,242,255,0.85)';
    for (let i = 0; i < 3; i++) {
      ctx.fillRect(bx + 4 + i * 5, -bh - 13, 2.6, 2.6);
    }

    // 桅杆
    ctx.strokeStyle = 'rgba(160,248,255,0.6)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(bx + bw / 2, -bh - 17);
    ctx.lineTo(bx + bw / 2, -bh - 38);
    ctx.stroke();

    // 桅顶航灯
    const navBlink = Math.sin(time * 4 + this.phase) > 0 ? 0.9 : 0.25;
    ctx.fillStyle = Utils.rgba(CFG.COLORS.dangerRGB, navBlink);
    ctx.beginPath();
    ctx.arc(bx + bw / 2, -bh - 40, 1.8, 0, Math.PI * 2);
    ctx.fill();

    // 烟囱
    ctx.fillStyle = '#101d24';
    Utils.roundRect(ctx, -this.len * 0.24, -bh - 15, this.len * 0.075, 16, 2);
    ctx.fill();
    ctx.strokeStyle = 'rgba(255,200,87,0.25)';
    ctx.stroke();
    ctx.fillStyle = 'rgba(255,140,60,0.35)';
    ctx.fillRect(-this.len * 0.23, -bh - 15, this.len * 0.055, 2);

    // 舰炮
    ctx.fillStyle = '#16262f';
    ctx.strokeStyle = 'rgba(95,242,255,0.5)';
    ctx.beginPath();
    ctx.arc(hl * 0.42, -bh - 3, 6, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
    ctx.strokeStyle = 'rgba(190,245,255,0.55)';
    ctx.lineWidth = 1.4;
    ctx.beginPath();
    ctx.moveTo(hl * 0.42, -bh - 3);
    ctx.lineTo(hl * 0.42 + 18, -bh - 12);
    ctx.stroke();

    // 舰尾深弹架
    ctx.fillStyle = '#0b151b';
    for (let i = 0; i < 3; i++) {
      ctx.beginPath();
      ctx.arc(-hl * 0.62 - i * 7, -bh + 2, 2.2, 0, Math.PI * 2);
      ctx.fill();
    }

    // 受击白闪
    if (this.hitFlash > 0) {
      ctx.save();
      ctx.globalAlpha = this.hitFlash * 1.6;
      ctx.fillStyle = '#e8fbff';
      ctx.beginPath();
      ctx.moveTo(-hl, -bh * 0.45);
      ctx.lineTo(-hl * 0.72, -bh);
      ctx.lineTo(hl * 0.55, -bh);
      ctx.lineTo(hl * 0.9, -bh * 0.3);
      ctx.lineTo(hl, bh * 0.18);
      ctx.lineTo(hl * 0.62, bh * 0.85);
      ctx.lineTo(-hl * 0.86, bh * 0.85);
      ctx.lineTo(-hl, bh * 0.32);
      ctx.closePath();
      ctx.fill();
      ctx.restore();
    }

    // 血条
    if (this.hp < this.maxHp && !this.sinking) {
      const total = this.maxHp * 12 - 3;
      const sx = -total / 2;
      const sy = -bh - 50;
      for (let i = 0; i < this.maxHp; i++) {
        ctx.fillStyle = i < this.hp
          ? 'rgba(255,200,87,0.9)'
          : 'rgba(232,251,255,0.14)';
        ctx.fillRect(sx + i * 12, sy, 9, 3);
      }
    }

    ctx.restore();
  }
}
